
import './App.css';
import { useEffect, useState } from "react";
import DataFetching from "./DataFetching";

function App() {
  return (
    <div >
      <DataFetching />

    </div>
  );
}

export default App;
